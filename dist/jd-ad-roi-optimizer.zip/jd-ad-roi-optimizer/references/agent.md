# 内部数据 Agent（自主执行能力）

让 AI 从「只能基于当前区间问答」升级为**能自己干活的内部助手**：
用户说「要哪几天的数据/分析/导出/画图」，它自己规划步骤、调内部接口、**写并运行新脚本**，
最后给结论。入口在 `/ai` 分析台右下角的 **「自主执行（Agent）」开关**。

## 实现方式（为什么不依赖 function calling）
模型端点不保证支持 tools/function-calling，所以用 **ReAct 式提示词协议**：
每一轮模型只输出一个 JSON 对象，我们解析后执行，再把结果作为观察喂回去，循环到 `final`。

```json
{"thought": "一句话说明这步干嘛", "tool": "工具名", "args": {...}}   // 继续干活
{"thought": "一句话", "final": "给用户的 markdown 答案"}            // 收尾
```

- 代码：`jd_roi/agent.py`（`TOOLS` 注册表 + `run(job, task, ...)` 执行环）。
- 接口：`POST /api/ai/agent`（body `{start,end,accounts,task}`）→ **立即返回 jobId**；
  事件走既有的 `GET /api/ai/stream?job=`，新增事件类型：
  - `plan`（本轮打算做什么）
  - `tool`（调用的工具名 + 参数）
  - `obs`（工具返回摘要，含耗时/成败）
- 前端把 plan/tool/obs 渲染成**执行时间线**（可折叠查看每次工具返回），
  思考过程仍走 `reasoning`，最终答案走 `content`（分片推送）。
- 事件载荷是**统一包一层** `{"t": <payload文本>, "seq": n}`（SSE 需要，多行文本必须转义），
  所以 `plan/tool/obs` 的 `t` 里还是一段 JSON，前端要**二次 `JSON.parse(d.t)`**。

## 可用工具（12 个）
| 工具 | 作用 |
| --- | --- |
| `coverage` | 本地已抓取覆盖（各账号各类型天数/首末日期）+ 库内最新一天 + 默认区间 |
| `fetch_data` | **触发内部抓取**指定区间（后台跑，立即返回；缺数据时用）|
| `scrape_status` | 抓取进度 / 下次补跑区间 |
| `analyze` | 区间**精炼指标摘要**（保本/放量线、账号合计、计划三窗口、类型拆解、词分层、SKU、定向缺口）—— 分析首选 |
| `raw` | 原始分析结构切片（`meta/totals/plans/skus/adjustments/words/typeSplit/targeting/targetingGaps/advice`）|
| `get_report` | 读本地缓存的整份 AI 报告要点 |
| `start_report` | 触发一次整份 AI 报告生成（后台，数分钟）|
| `list_files` / `read_file` | 看/读项目内文件 |
| `write_file` | **写新文件**（沙箱：`scripts/agent/`、`data/` 下）|
| `run_python` | 用项目解释器**运行脚本或一段代码**，返回 stdout/stderr（超时 180s）|
| `http_api` | 直接打本机 `127.0.0.1:8011` 的内部接口 |

## 运行参数与护栏
- `MAX_STEPS = 9`（慢模型，别太贪）；`PLAN_MAX_TOKENS = 4000`；每步 `temperature=0.2`。
- **解析失败不罚步数**：模型偶尔不给合法 JSON，重试提示最多 3 次且**不计入步数预算**。
- 路径越界防护：读写一律限制在项目目录内；写文件只允许 `scripts/agent/` 与 `data/`。
- 脚本执行：`cwd=项目根`，**自动注入 `PYTHONPATH=项目根`** —— 否则脚本在
  `scripts/agent/` 下 `from jd_roi import ...` 会 ImportError（踩过）。
- 输出上限 `STDOUT_LIMIT=8000`，单条观察回喂上限 `OBS_LIMIT=6000`。
- `reset` 只在**重试**时发（`llm.chat` 里 `attempt > 0` 才回调），
  否则会把前面步骤累积的思考误清掉。

## 实测
- 「把近 20 天每天总花费与 ROI 导出 CSV」→ 6 步：`coverage` → `read_file dailystore.py`
  → `write_file scripts/agent/export_daily_cost_roi_20d.py` → `run_python`（报错）
  → 改脚本 → `run_python`（成功产出 `data/agent/daily_cost_roi_20d.csv`）。
- 「覆盖到哪天 + 近 7 天两账号 ROI + 是否低于保本」→ 3 步收尾（`coverage` → `analyze` → `final`），
  约 35s，结论引用了真实数字（ROI 3.37/4.22、保本 3.82/3.27、全站智能 2.99、松茸礼盒 0.38）。

## 安全定位
这是**本机、单用户、内部**工具，允许它写并运行脚本（用户明确要求「自己写新脚本」）。
若将来要对外或多用户暴露，必须再加：脚本白名单/静态检查、命令级审计、容器隔离、按用户鉴权。
