# 数据流水线（抓取 → 按天入库 → 分析 → 报表）

> 项目根目录 = 用户当前工作区（含 `jd_roi/` 包）。本文件描述流程与关键口径，
> 具体命令里的 `<venv>` 指项目内 `.venv/Scripts/python.exe`（Windows）。

---

## 1. 三种运行形态

| 形态 | 说明 |
|---|---|
| **v1（旧）** | 固定区间跑一次，回填 Excel + 出 HTML |
| **v2（分析口径修正版）** | `analyze2` + `report2`，跨账号按 SKU 交叉 + 操作日志复盘 |
| **v3（常驻服务）** | 每天 0 点自动抓前一天入库，任意区间秒级分析 |

---

## 2. 标准流程（v2/v3）

```bash
# 1) 登录（每个账号一个独立 Profile，扫码一次）
<venv> -m jd_roi.login [--account=main|b]

# 2) 抓取（逐账号；京准通 + 该店铺商智都要抓）
<venv> -m jd_roi.scrape_all  --account=main w0=YYYY-MM-DD:YYYY-MM-DD w1=... w2=...
<venv> -m jd_roi.scrape_all  --account=b    w0=... w1=... w2=...
<venv> -m jd_roi.scrape_daily <start> <end> --account=main   # 日粒度，用于调整前后对比
<venv> -m jd_roi.scrape_oplog sweep <start> <end> --account=main   # 操作日志（按周分段）

# 3) 分析 → 4) 报表
<venv> -m jd_roi.analyze2 <start> <end>   # -> data/analysis2.json
<venv> -m jd_roi.report2                  # -> ad_roi_report_v2.html

# 5) 生成否定词清单（分析产物）
<venv> -m jd_roi.build_negatives          # -> data/negatives_b.json

# v3 常驻服务
uvicorn jd_roi.webapp:app --host 127.0.0.1 --port 8011
<venv> -m jd_roi.scrape_day [--days N | <start> <end> --force]
```

**改 `report2.py` 后必须重启服务**（无 `--reload`）；页面是 SPA，商品表在「商品ROI」tab。

---

## 3. 按天入库

- 路径：`<DATA_DIR>/daily/<账号>/<YYYY-MM-DD>/<source>.json.gz`
- **按天存、区间算**：接口虽支持区间查询，但任意区间频繁拉接口会触发限流；按天落盘后区间是本地聚合，秒级且不受限流影响。
- **回刷窗口 `JD_REFRESH_DAYS`（默认 15）**：京准通是「点击后 15 天归因」，昨天的数据后面还会长 → 每晚重抓最近 15 天覆盖写入。商智当天结算后不再变化。

---

## 4. 关键口径（必须保持一致）

- **归因口径**：点击 15 天内累计成交订单（`clickOrOrderDay=15`、`clickOrOrderCaliber=0`）。
- **单日/短区间报表的广告数 ≠ 商智后台当天的数**：归因会把成交散落到点击后的 15 天内。
  当天 direct（当点当单）只是其中一部分，还有 indirect（往日点击、今天转化）。
  **看长期区间（≥14 天）才趋近稳定可比。**
- **件数 vs 订单数单位不同，不能相加**：商智「成交商品件数」是**件数**，京准通是**订单数**。
  件数勾稽：`自然件数 ≈ 商智总件数 − 广告订单数 × (商智件数 ÷ 商智订单数)`。
- **广告渗透率** = 广告成交 ÷ 各店商智成交合计；>100%（归因跨期）标记为不可比。
- 「概览」与「智能投放报表」的订单/金额口径可能不同（成交订单 vs 下单订单）——同一次分析内必须统一并注明。

---

## 5. 多账号 / 跨店铺（按 SKU 合并）

```python
ACCOUNTS = [
    {"key": "main", "label": "主账号", "account_id": 111, "user_data_dir": "auth/browser_profile"},
    {"key": "b",    "label": "账号B", "account_id": 222, "user_data_dir": "auth/browser_profile_b"},
]
```
（也可用环境变量 `JD_ACCOUNTS='[...]'` 覆盖）

- **SKU 是跨店铺主键**：京准通「智能投放-商品」返回 `skuId`，与商智 `sku_id` 完全一致。
- 广告数据按 `skuId` **跨账号累加**；商智数据**按店铺分别保留**（`shops` 字段）。
- **v2 修正**：统计「广告」时两个账号**全部相加**（v1 只算账号B却把两店商智都算进分母，导致渗透率虚高）。商智仍按店铺分别保留。
- 换店流程：改 `ACCOUNTS` / 日期 / `user_data_dir` → 删旧 Profile → 重新扫码。

---

## 6. 计划类型拆分

| `campaignType` | 含义 | 明细来源 |
|---|---|---|
| 61 | 智能化 | 智能投放报表（有 `skuId`） |
| 2 | 快车-关键词 | 智能投放报表 |
| 153 | 全站智能推广 | **不在智能投放报表里**，自带 `spuId` = 商智 `sku_id`，用「一计划=一商品」补进 SKU 表（否则漏掉主账号约 40% 花费） |

---

## 7. 成本接口（供货方 ERP）

- 地址形如 `http://<ip>/api/open/sku-costs`（Token 走 HTTP）。
- 返回 `skus = {"<京东skuId>": {...}}`，**key 就是京东 skuId** → 本地 `costs["skus"].get(str(sid))` 是**精确主键命中**。
- `sku_id` 查询参数**实测无效**（返回体与不带参数逐字节相同）→ 一次拉全量 → 存 `data/costs_cache.json` → 按 skuId 查字典。
- 单 SKU 字段：`supply`（到手结算价/收入）、`supplyGross`、`shipping`、`package`、`labor`、`platformRate`、`_goodsCost`（货款）等。
- **覆盖率要报告**：ERP 与商智两端 SKU 集合往往只有约一半交集；未命中的在报表标 `*`。
- ⚠️ 遗留风险：`.env` 里是公网 IP + 纯 HTTP，Token 明文过网，建议 HTTPS / IP 白名单 / 轮换。

---

## 8. 环境变量

`JD_DATA_DIR` / `JD_AUTH_DIR` / `JD_CONFIG_DIR` / `JD_EXCEL_PATH` / `TZ` /
`JD_SCHEDULE_HOUR` / `JD_SCHEDULE_MINUTE` / `JD_REFRESH_DAYS` / `JD_RUN_ON_START` /
`JD_ENABLE_SCHEDULER` / `JD_SW_MAX_ROWS` / `JD_WEB_PORT`。
账号：`JD_ACCOUNTS`（JSON）> `<CONFIG_DIR>/accounts.json` > 内置默认。
