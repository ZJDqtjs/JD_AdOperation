# 接口参考（抓取 + 写入）

> 京准通为 SPA，数据走 JSON 接口。在**已登录页面的上下文内** `page.evaluate(fetch)`，
> 带 `credentials:'include'` 与业务头即可自动带 Cookie。

```js
headers: {'Content-Type':'application/json','accept':'application/json, text/plain, */*',
          'referer':'https://jzt.jd.com/','language':'zh_CN','siteid':'0','loginmode':'0'}
```

---

## 1. 读取接口

| 数据 | 站点（先访问建立 SSO） | 接口 |
|---|---|---|
| 推广计划总览 | `jzt.jd.com/msa/#/list/tab/plan?objective=overview` | `POST atoms-api.jd.com/dspad/msa/promolist/overview/campaign` |
| 智能投放-账户 | `jzt.jd.com/jst/#/report/account` | `POST jzt-api.jd.com/reweb/jst/account/account/list` |
| 智能投放-计划 | 同上 | `POST jzt-api.jd.com/reweb/jst/account/campaign/list` |
| 智能投放-商品 | 同上 | `POST jzt-api.jd.com/reweb/jst/account/sku/list`（含 `skuId`） |
| **智能投放-搜索词** | 同上 | `POST jzt-api.jd.com/reweb/jst/effect/searchword/list` |
| 智能投放-订单/地域 | 同上 | `POST /reweb/jst/effect/order/list`、`/location/list` |
| 快车-关键词报表 | `jzt.jd.com/report/index.html/#/rtb/basic/keyword?hideNav=1` | `POST jzt-api.jd.com/reweb/msa/orientation/keyword/list` |
| 商智-商品明细 | `jdsz.jd.com/szweb/view/product/productDetail.html` | `POST szgateway.jd.com/api/lowcode/productDetail/table/productTable.ajax` |
| 商智-流量概况 | `jdsz.jd.com/szweb/view/flow/flow-summary.html` | `POST /api/lowcode/flowSummary/getCoreSummary.ajax`、`/productFlow/getFlowSrcTop.ajax` |
| 商智-广告概况 | `jdsz.jd.com/szweb/view/market/advert-summary.html` | `POST /api/lowcode/flow/payFlow/advertSummary/getSummaryData.ajax` |
| 操作日志 | `jzt.jd.com/logging/#/business?businessType=-16` | `POST jzt-api.jd.com/logplatform/common/list/query` |
| 操作日志-枚举 | 同上 | `POST /logplatform/common/business/info`、`/logplatform/common/list/opt` |

公共请求体（按需覆盖）：
```json
{"isDaily":false,"startDay":"YYYY-MM-DD","endDay":"YYYY-MM-DD","obys":"impressions|desc",
 "filters":[],"clickOrOrderDay":15,"clickOrOrderCaliber":0,"orderStatusCategory":1,
 "page":1,"pageSize":200,"giftFlag":0,"promotionMode":null,"columns":["..."],"requestFrom":0}
```

---

## 2. ⭐ 写入接口（否定词 / 出价 / 预算）

**写入前必须**：① `browser.session_ok(page)==True`；② 先 dry-run 预览；③ 用户确认后再提交。

### 2.1 否定词（快车）
| 动作 | 接口 |
|---|---|
| 列当前否定词 | `POST /ht/normal/keyword/negative/list/new` |
| **加否定词** | `POST /ht/normal/keyword/negative/add` |
| 批量上传否定词 | `POST /ht/normal/keyword/negative/upload` |
| 计划关键词列表 | `POST /kuaiche/keyword/list` |

- 否定词为**精确匹配**。
- 真实请求体尚未抓包（需登录后打开「关键词-否定词」弹窗捕获）。
- 参考实现：`jd_roi/build_negatives.py` 生成清单；写入脚本需按上表补全请求体。

### 2.2 智能投放-爆款场景 出价/预算（已实测可用）
| 动作 | 接口 |
|---|---|
| 读计划配置 | `POST jzt-api.jd.com/growth/scenario/get`  `{"campaignId":"<id>","requestFrom":0}` |
| 写回配置 | `POST jzt-api.jd.com/growth/scenario/update` ← 把 get 返回的 data 原样回传，只改目标字段 |

- `biddingPrice` = 期望成交投产比；`dayBudget` = 日预算；`campaignType=61 / scenarioType=2` 为爆款场景。
- ⚠️ **get 返回的顶层 `campaignId` 为 null，直接回传会被后端当「新建计划」并报「计划名称已存在」——必须补上顶层 `campaignId`**。
- 参考实现：`jd_roi/adjust_bid.py`（含 `plan` / `apply --dry-run` / `apply --yes` 三种模式）。

---

## 3. 关键约束与踩坑

- **必须先访问站点首页建立 SSO**，否则接口返回 `code:-401` / `-100 非法请求`。
- **必须分页**：以返回行数 `< pageSize` 为终止条件；只看第一页会严重低估花费与废词。
- **操作日志接口静默截断**：`beginTime~endTime` 跨度过大（实测 8/15~10/5）只返回 8 月记录 → 必须**按 7 天分段抓取再合并**（`scrape_oplog sweep`）。
- **商智只提供到「昨天」**：`endDate >= 今天` 时返回 `code:0` + `data:[]`（**不报错！**）。
- **商智动态签名头 `user-mnp/user-mup/uuid` 存活期很短**：一次会话里先抓别的报表再抓商智会返回 `rawCode:-407` 或空数组 → 每次请求前重新开页面捕获头（`scrape_sz.SzSession`）。
- **智能投放搜索词接口限流 `code:-3010`**（"操作次数已超过上限"）：按 `obys:"cost|desc"` 排序**只取前 2000 行**（覆盖 99.9% 花费），分页 sleep 0.35s + 命中限流退避 22s 重试。
- **搜索词接口不返回 `campaignId`**，只有 `campaignName`，聚合必须以计划名为键。
- 接口返回的商品名含 `&amp;` 等 HTML 实体，渲染前 `html.unescape` 再转义。
- 沙箱下 `tempfile` 默认目录不可写会让 Playwright 报 `EPERM ... playwright-artifacts` → 跑脚本前把 `TEMP/TMP` 指到工作区目录内。

---

## 4. 登录态

- 京东现行票据：`pin / pinId / thor / sdtoken`（**没有 pt_key**，勿用 pt_key 判断）。
- 判定必须问服务端：`browser.session_ok(page)`（`/common/logininfo` 返回 `code==1`）。
- cookie 里 pin 还在但服务端会话过期 → 仍算**未登录**；访问 `jzt.jd.com` 会被重定向到 `/gw/index`。
- 登录方式：**扫码**，必须 headed，用持久化 Profile（保留 cookie + localStorage）：
  `pw.chromium.launch_persistent_context(user_data_dir=auth/browser_profile[_<key>], headless=False)`
- 京麦登录页默认密码登录，二维码要先点右上角 `.scan-login` 图标。
