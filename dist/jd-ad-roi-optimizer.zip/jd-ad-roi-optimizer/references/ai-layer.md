# AI 解读层（可选，独立于规则层）

把**本地已抓取**的确定性指标交给 LLM，让它**套用本 skill 的方法论**做判断
（诊断/归因/取舍/优先级/话术）；算数仍由代码负责。**不修改** analyze2 / report2 的逻辑。

## 两条设计红线（用户明确要求）
1. **拿本地实际已抓取的数据分析**，不是自己拍一个区间。
   - 区间由 `analyze_ai.local_range()` 从按天库算出：取库内最新一天，向前回溯，
     遇断层即停，最多 `JD_AI_RANGE_DAYS`（默认 7）天 → 保证不分析没抓过的日期。
   - 报表/JSON 的**默认区间**也走 `webapp.ui_range()`（同样贴本地数据），
     这样默认页面与夜间 AI 的区间一致。
2. **AI 的结论/建议必须"套方法论"得出，而不是把规则层的结果换个格式再念一遍。**
   - 因此 `build_digest()` **不喂** `advice.summary`（规则层结论），也**不喂**计划的 `tier` 档位；
     只给原始指标（ROI / 保本 / 放量线 / CTR / CVR / 花费 / 词分层 / 类型拆解 / 近期操作），
     让模型自己按方法论下判断。
   - 输出 schema 也与规则层**不同构**：`headline / health / diagnosis / account_reads /
     plan_judgements / keyword_plan / reallocation / sequence / watchlist / risks / confidence`。

## 独立 AI 分析台 `/ai`（报告 + 对话框）
报表页的 AI 卡片只读、且嵌在「总结」页里；运营还想就具体问题追问，
于是单独做了一个页面 `/ai`（8011）：

- **左栏**＝本区间的完整 AI 报告（复用 `report2._ai_block`，口径与报表页一致），
  额外含「**未用起来 / 待优化的投放功能**」板块（见下）。
- **右栏**＝对话框（sticky）：可就这份数据连续追问，例如
  「定向人群（DMP）要不要开」「哪些地域该屏蔽」「这周只改哪三件」。
- 对话历史存在浏览器 `localStorage`（按 区间+账号 分键），后端不落盘。
- 页面代码：`jd_roi/ai_page.py`；路由 `GET /ai`。

### 对话框后端（流式）
- 接口：`POST /api/ai/chat`，请求体 `{start,end,accounts,question,history:[{role,content}]}`，
  返回 `text/plain` **流式**文本（前端 `fetch`+`ReadableStream` 边收边渲染）。
- 上下文由后端准备并**按 (区间,账号) 缓存**（`webapp._chat_context`）：
  `analyze_ai.prepare_chat_context()` → 同一份 `build_digest()` 摘要 + 方法论。
- 提示词 `CHAT_SYSTEM`（`analyze_ai.py`）强制：只依据摘要、套方法论、引用具体计划/词/地域、
  未启用功能要提示、不确定就说不确定、篇幅 300~600 字。
- 流式实现：`llm.chat_stream_iter()`（逐分片 yield，不整轮重试，前端不会收到重复内容）。
- 实测：单问 ~10s，详细多轮 ~60s（14 token/s）。

## 未使用功能建议（`targeting_advice`）
用户明确要求「比如我还没用的定向人群、定向地域等，AI 也要给建议」。为此：

1. **新数据源**：`jd_roi/scrape_target.py` 抓两类定向数据入按天库——
   - `crowd`：人群报表（`orientation/crowd/list`，`isDaily=True`），含 DMP `dmpName`、拉新数/GMV、成交人数；
   - `area`：地域报表（自定义报表模板 `config/report_templates/area_41.json` → `queryData`），`mappedAreaName`。
   每晚随主流程抓取（`scrape_day.py` 的 `("crowd","area")` 块）。
2. **规则层先算客观缺口**：`analyze2.targeting_gaps()` 输出「main 未启用人群定向」
   「人群花费全来自系统默认人群」「29 个地域中 X 个零成交」等**事实**（不臆测）。
3. **喂给 AI**：`build_digest()` 增加 `targeting`（人群/地域 top 行）与 `targeting_gaps`；
   schema 增加 `targeting_advice[]`（feature/status/evidence/method/suggest/priority），
   系统提示要求**引用客观证据**并给可落地做法（建什么包、溢价怎么设、怎么小预算测）。
4. **展示**：报表 AI 卡片与 `/ai` 报告都会渲染「未用起来 / 待优化的投放功能」板块。

## 位置与命令
- 代码：`jd_roi/llm.py`（OpenAI 兼容客户端）+ `jd_roi/analyze_ai.py`（摘要+提示+校验）
- 命令：
  ```bash
  python -m jd_roi.analyze_ai            # 全部账号，区间=本地最近 AI_RANGE_DAYS 天
  python -m jd_roi.analyze_ai --account=b
  python -m jd_roi.analyze_ai --start=2026-10-03 --end=2026-10-09
  python -m jd_roi.analyze_ai --dry-run  # 只打印摘要与提示词，不调用
  ```
- 产物：`data/ai_advice.json` + `data/ai_advice.md`
- **网页展示**：报表页 `/report`（8011）**「总结」标签页内**有「AI 运营解读」卡片（不要放到所有 tab）。
  - 只有缓存解读的 `range`/`accounts` 与当前所选区间**匹配**时才展示；否则显示「生成本区间解读」按钮。
  - 按钮 → `POST /api/ai/run`（后台线程）→ 轮询 `GET /api/ai/status` → 完成后自动刷新。

## 与每晚自动任务的集成
- 夜间抓取完成后自动生成解读并落盘，供报表页直接读取 —— 无需手动跑。
- 实现：`scrape_day.run_background(..., after=<回调>)` → 抓取**成功**后调用
  `webapp._ai_after_scrape(summary)` → 用 `analyze_ai.local_range()` 定区间 → `AiRunner.run_background()`。
- 开关：`JD_AI_ENABLED`（默认 1）、`JD_AI_RANGE_DAYS`（默认 7）。

## 模型来源（优先级）
1. 环境变量 `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL`（项目 `.env` 已配置，`source=env`）
2. WorkBuddy `~/.workbuddy/models.json` 里第一个含 `url`+`apiKey` 的条目（可用 `LLM_MODELS_JSON` 覆盖路径）
3. 都缺 → 抛 `LlmConfigError`

> 该项目使用自有的 OpenAI 兼容端点，模型 `blian_qwen38_flash`（写在项目 `.env`）。
> 端点/key 是用户自有的，项目已完全独立于 WorkBuddy 的 `models.json`。
> ⚠️ 真实 Key 只放 `.env`（已 gitignore），不要写进代码或提交。

## 设计要点（为什么这样搭）
1. **喂摘要，不喂全量**：analysis2.json 约 1MB，直接塞给模型烧钱且超窗。
   `build_digest()` 抽出 meta/账号合计/计划三窗口/类型拆解/高频 SKU/词分层/近期操作，
   用**紧凑 JSON**（`separators`）压到约 2.4 万 token，并**剔掉三期零花费的计划**。
2. **方法论来自本 skill**：`load_methodology()` 优先读 `references/methodology.md` + `diagnosis-playbook.md`，
   读不到则用内置精简版。这样"判断标准"与 skill 保持单一来源。
3. **防幻觉护栏**（`validate()`）：
   - `plan_judgements[].campaignId` 必须在摘要计划里 → 否则记 `issues`；
   - `keyword_plan[].negate[].word` 只能来自该计划的 `waste/low`，`boost` 只能来自 `good` → 否则 `warnings`；
   - `health.score` 必须在 0~100 → 否则 `warnings`。
4. **不自动执行**：提示词强制模型输出「待人工审阅」，所有写操作仍需人工确认（见 diagnosis-playbook §8）。

## 铁律
- 规则层保持纯净可复现；AI 层是附加物，随时可关（不跑就不影响报表）。
- 模型只解读，不改数字、不落库、不执行。

## 运维要点（实测踩坑，务必遵守）
1. **必须走 SSE 流式**（`chat(stream=True)` 是默认）。该端点模型吞吐仅约 **14 token/s**
   （大量 token 花在 reasoning 上），非流式一次几千 token 要几分钟，**必然触发读超时**；
   流式每个分片重置读超时，长文不再被掐断。
2. **模型选择**：`blian_qwen38_flash` 快（小请求 3s）；`blian_qwen35_plus` 实测极慢
   （小请求都能 90s 超时）。**用 38_flash**。
3. **`llm.py` 会在 import 时触发 `.env` 加载**（`from . import settings`），
   否则单独 `import jd_roi.llm` 时读不到 `LLM_*`，会静默回退到 `models.json` 的旧模型。
4. **JSON 容错三件套**（模型偶发吐坏 JSON）：
   - `chat_json(parse_retries=2)`：解析失败**重新调用**；
   - `extract_json()` 内置 `_repair()`：可从截断/轻微畸形里抢救出对象；
   - `normalize()`：收敛字段名漂移（如 `plan_actions`→`plan_judgements`、`keywords_negate`→`negate`）。
5. **`LLM_MAX_TOKENS` 默认 8000**：新 schema 字段多，3000 会被截断（`_repair` 只救回前半段，
   `keyword_plan/reallocation/sequence` 等会丢）。系统提示已要求"控制篇幅、输出完整 JSON"。
6. **校验器容忍带注解数值**：`health.score` 形如 `"84/100"` 会提取前导数字，不报假警。
7. **一段完整生成约 4~8 分钟**（2.4 万 token 输入 + 长文输出，14 token/s）。夜间任务不赶时间，可接受。
