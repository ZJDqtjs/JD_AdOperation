---
name: jd-ad-roi-optimizer
description: "分析京东店铺/广告账户的运营与投产比，抓取京准通+商智数据、诊断计划与关键词、给出可执行的优化建议（否定词/出价/预算/词增删），并沉淀京东快车（搜索广告）运营方法论。当用户要求分析京东广告ROI、投产比、关键词优化、否定词、预算分配，或说『帮我改善店铺运营/看看数据/优化店铺』，或切换店铺/账号时使用。"
agent_created: true
---

# 京东广告运营优化 + 数据诊断

把「登录 → 抓数 → 分析 → 出优化建议 → （确认后）落地调整」固化为标准流程，
并用一套**京东快车底层逻辑方法论**解释结论、指导动作，帮助持续改善店铺运营。

触发场景：
- 用户要求分析京东广告账户/店铺的投产比、关键词、否定词、预算分配
- 用户说「帮我分析运营数据 / 改善店铺运营 / 看看这个账号怎么样」
- 用户给出 ROI 模板要求「完成它」，或说「换店/换账号再跑一遍」
- 关键词：京准通、商智、快车、投产比、ROI、搜索词、否定词、预算分配、全站推广

> **数据与结论一律以接口真实返回为准**，禁止用示例/模板里的数字当结果。

---

## 1. 先确认工作区与登录态（每次必做）

1. 定位项目根目录（含 `jd_roi/` 包与 `.venv`）。Windows 下用 `<root>/.venv/Scripts/python.exe -m jd_roi.<module>`。
2. **验证登录态**（写/抓取都依赖）：
   - 只看 `browser.has_login()`（cookie 里 pin 存在）**不可靠** —— 服务端会话过期时 cookie 仍在。
   - 必须问服务端：`browser.session_ok(page)` 返回 `True`（`/common/logininfo` `code==1`）。
   - 失效表现：访问 `jzt.jd.com` 被重定向到 `jzt.jd.com/gw/index` 或 `passport.jd.com`。
3. 登录失效 → **如实告知用户需重新扫码**（`python -m jd_roi.login --account=<key>`），
   **不要假装能操作**。raw 数据早已入库时可先用本地数据出分析，但写操作必须等登录。

---

## 2. 工作流

### A. 分析（读）—— 随时可做
1. 需要最新数据 → 抓取（见 `references/data-pipeline.md`）；已有 `data/analysis2.json` 可直接分析。
2. `python -m jd_roi.analyze2 <start> <end>` → `data/analysis2.json`
3. `python -m jd_roi.report2` → `ad_roi_report_v2.html`（自包含 HTML）
4. `python -m jd_roi.build_negatives` → `data/negatives_b.json`（否定词待执行清单）

### B. 出建议 —— 套用本 skill 的规则
- **诊断规则** → `references/diagnosis-playbook.md`（定档、词分层、决策树、风险控制）
- **方法论（为什么这样调）** → `references/methodology.md`（计划分类、测图测词测人群、低出高溢、四指标）
- **接口/口径/踩坑** → `references/api-reference.md`、`references/data-pipeline.md`

### B2. AI 解读层（可选）—— 让模型**套方法论**做判断
规则层保持确定性，AI 层独立做解读，**不碰规则层**：
```bash
python -m jd_roi.analyze_ai [--account=b] [--start=.. --end=..] [--dry-run]  # -> data/ai_advice.{json,md}
```
- 区间**贴本地已抓取的数据**（`local_range()`），不自己拍区间；只读本地按天库，不打京东接口。
- 输入是**原始指标摘要**（不含规则层的结论/档位）+ 本 skill 方法论，让模型自己下判断；
  输出为诊断/逐计划判断/词候选/预算再分配/执行顺序/未启用功能建议，经**防幻觉校验**（ID/词来源/数值合理性）。
- **独立分析台 `/ai`**（8011）：左栏完整 AI 报告，右栏**对话框**可连续追问
  （「定向人群要不要开」「哪些地域该屏蔽」…）；对话走 `POST /api/ai/chat`（**立即返回 jobId**），
  再挂 `GET /api/ai/stream` 的 SSE 看**思考过程 + 正式回答**。
- **生成在服务端后台跑**（`jd_roi/aijobs.py`）：页面切走/刷新/断网都不中断，
  回到页面自动重挂回放续看（job 里留着全部事件）。
- 内置**「未用起来 / 待优化的投放功能」**建议：结合 `crowd`（人群/DMP）与 `area`（地域）
  两路新抓的数据 + 规则层算出的客观缺口，AI 给出建包/溢价/小预算测试等可落地做法。
- 模型来源：环境变量 → WorkBuddy `models.json`。详见 `references/ai-layer.md`。

### B3. 内部数据 Agent（自主执行）—— 让 AI 自己干活
`/ai` 分析台有「**自主执行（Agent）**」开关。打开后用户直接下达任务（「要哪几天的数据/导出/画图」），
Agent **自己规划步骤**并调用内部工具，必要时**写并运行新脚本**，最后给结论：
```bash
POST /api/ai/agent   {"accounts":"main,b","task":"把近20天每日花费与ROI导出成CSV"}
```
- 12 个工具：`coverage` / `fetch_data`（触发抓取）/ `analyze`（精炼指标）/ `raw` / `get_report` /
  `start_report` / `list_files` / `read_file` / `write_file` / `run_python` / `http_api` / `scrape_status`。
- 协议：ReAct 式，每轮模型只输出 `{"thought","tool","args"}` 或 `{"thought","final"}`；
  执行过程以 `plan/tool/obs` 事件流到前端**执行时间线**，同样支持离开页面不中断、回来续看。
- 沙箱：文件读写限项目内，写文件只在 `scripts/agent/`、`data/`；脚本执行注入
  `PYTHONPATH=项目根`、超时 180s。详见 `references/agent.md`。

### C. 落地调整（写）—— **必须用户确认**
1. 生成待执行清单（如否定词），**先 dry-run 预览**；
2. 把「要改什么、改多少、影响谁」列清楚给用户审阅；
3. **用户明确确认后**才执行 `--yes`；
4. 执行后**回读校验**（re-read 确认已生效）。

---

## 3. 核心分析规则（速查）

**保本 ROI = 1 / 毛利率**（口径见 diagnosis-playbook §1）。

**三档定档**：`ROI≥4` 🟢放大（+预算20~30%）｜`保本≤ROI<4` 🟡优化｜`ROI<保本` 🔴止损。

**词分层**：高效词（订单≥2 且 ROI>保本）→提价；废词（花费≥阈值且 0 单）→否定；低效词（花费≥10 且 ROI<保本）→降价/否定。

**⚠️ 否定词必须跨窗口确认**：只在单窗口命中的低效/废词**不能直接否定**，
否则会误否高效大词（真实教训：某词 w1 花¥137/12单，仅按 w2 粗筛会被误判）。三级置信度见 `build_negatives.py`。

**指标诊断**：曝光低→出价/词/低出高溢；CTR 低→创意+人群（影响链接权重）；CVR 低→内功；客单突变→查 SKU 拼接。

---

## 4. 输出结构

1. 全局总览表（花费/ROI/上期ROI/档位，**涨红跌绿**——国内市场习惯）
2. 结构拆解（按计划类型，指出主力与拖累项）
3. 逐计划：「现状 → 关键词增删（可直接复制）→ 出价/预算动作 → 目标ROI」
4. 全局优先级：立刻做（止血）/ 随即做（提效）/ 放量（高效加预算）
5. 预算再分配测算 + 口径提醒（单日波动、保本口径、成本覆盖率）

---

## 5. 铁律

- **写操作（否定词/改价/改预算）必须：验证登录 → dry-run → 用户确认 → 执行 → 回读校验。**
- 派生脚本改动后，若服务在跑，**必须重启服务才生效**（`report2.py` 改完重启 8011）。
- 分析只读操作可以自主进行；一切会影响账户真实花费的动作，**等用户点头**。
- 不把账号/密钥写入本 skill；账号信息只放项目的本地配置。
- 单日/短区间数据波动大，**结论要注明口径与观察期**，必要时建议再观察 2~3 天。

---

## 6. 参考文件索引

| 文件 | 内容 |
|---|---|
| `references/methodology.md` | 京东快车底层逻辑方法论（视频沉淀 + 项目对应） |
| `references/diagnosis-playbook.md` | 诊断手册：保本ROI、定档、词分层、决策树、复盘、安全约束 |
| `references/api-reference.md` | 抓取接口 + **写入接口（否定词/出价/预算）** + 踩坑 |
| `references/data-pipeline.md` | 流水线、按天入库、口径（含**分时 `hourly` 可选数据源**）、多账号、成本接口、环境变量 |
| `references/ai-layer.md` | AI 解读层：LLM 客户端、摘要构建、防幻觉校验、思考流、可续传 job、**分时/定向建议** |
| `references/agent.md` | **内部数据 Agent**：自主执行环、ReAct 协议、12 个内部工具、沙箱与护栏 |
